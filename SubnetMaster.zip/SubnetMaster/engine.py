import datetime
import os
from logic import get_network_info, get_subnet_division, get_vlsm_allocation

# --- Professional UI Colors (ANSI) ---
CLR_RESET  = "\033[0m"
CLR_BOLD   = "\033[1m"
CLR_CYAN   = "\033[36m"
CLR_GREEN  = "\033[32m"
CLR_RED    = "\033[31m"
CLR_YELLOW = "\033[33m"
CLR_BLUE   = "\033[34m"

def print_banner():
    # We removed the emoji to prevent encoding/width issues in different terminals.
    # This ensures perfect alignment and 100% compatibility.
    print(f"\n{CLR_CYAN}************************************************")
    print(f"|                                              |")
    print(f"|             IPv4 SUBNETMASTER                |")
    print(f"|        [ Professional Network Tool ]         |")
    print(f"|______________________________________________|{CLR_RESET}")
    print(f"{CLR_CYAN}================================================")
    print(f"          Network Engineering Toolkit")
    print(f"================================================{CLR_RESET}")

def print_divider():
    print(f"{CLR_CYAN}------------------------------------------------{CLR_RESET}")

def save_report(content, filename_prefix):
    """Saves the report into a dedicated 'reports/' folder relative to this script."""
    try:
        # 1. Find the absolute path of where the script lives (the 'home' directory)
        script_dir = os.path.dirname(os.path.abspath(__file__))
        reports_dir = os.path.join(script_dir, "reports")

        # 2. Ensure the 'reports/' folder exists so we don't clutter the root workspace
        if not os.path.exists(reports_dir):
            os.makedirs(reports_dir)

        # 3. Create the filename with timestamp
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"Report_{filename_prefix}_{timestamp}.md"
        full_path = os.path.join(reports_dir, filename)

        # 4. Write the file using the full, absolute path
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content)
        
        print(f"\n{CLR_GREEN}[✓] Report saved successfully!{CLR_RESET}")
        print(f"    Location: {os.path.join('reports', filename)}{CLR_RESET}")

    except Exception as e:
        print(f"\n{CLR_RED}[!] Failed to save report: {e}{CLR_RESET}")

def os_id():
    import random
    return str(random.randint(100, 999))

def run_analysis():
    print(f"\n{CLR_YELLOW}[Mode: Single Network Analysis]{CLR_RESET}")
    ip = input("Enter the IP address (e.g., 192.168.1.1): ").strip()
    mask = input("Enter the Subnet Mask (e.g., 255.255.255.0): ").strip()
    
    results, error = get_network_info(ip, mask)
    
    if error:
        print(f"{CLR_RED}[!] ERROR: {error}{CLR_RESET}")
        return

    report = []
    report.append(f"# IPv4 SubnetMaster Analysis Report")
    report.append(f"**Date:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    report.append(f"### Input Details\n- **Input IP:** {results['input_ip']}\n- **Subnet Mask:** {results['subnet_mask']}")
    report.append(f"\n### Network Breakdown\n"
                  f"- **Subnet Prefix:** {results['subnet_prefix']}\n"
                  f"- **IP Classification:** {results['ip_classification']}\n"
                  f"- **Wildcard Mask:** {results['wildcard_mask']}\n"
                  f"- **Network Address:** {results['network_address']}\n"
                  f"- **Broadcast Address:** {results['broadcast_address']}")
    report.append(f"\n### Host Information\n"
                  f"- **Total Hosts:** {results['total_hosts']}\n"
                  f"- **Host Bits:** {results['host_bits']}\n"
                  f"- **Usable Range:** {results['usable_range']}\n"
                  f"- **Usable Hosts:** {results['usable_hosts']}")

    print(f"\n{CLR_CYAN}================================================")
    print(f"      📊 SUBNETMASTER ANALYSIS REPORT")
    print(f"================================================{CLR_RESET}")
    for key, value in results.items():
        if not key.startswith("input_"): 
            label = key.replace("_", " ").title()
            print(f"{CLR_BOLD}{label:<20}:{CLR_RESET} {value}")
    print(f"{CLR_CYAN}================================================{CLR_RESET}")

    save_choice = input(f"\n{CLR_YELLOW}Would you like to save this report as Markdown? (y/N): {CLR_RESET}").lower()
    if save_choice == 'y':
        default_name = results['input_ip'].replace('.', '_')
        # Use the cleaned up version of the input IP as the filename prefix
        safe_prefix = default_name.replace('.', '_').replace('/', '_')
        
        save_report("\n".join(report), safe_prefix)

def run_division():
    print(f"\n{CLR_YELLOW}[Mode: Subnet Division]{CLR_RESET}")
    parent = input("Enter Parent Network (e.g., 192.168.1.0/24): ").strip()
    try:
        num = int(input("How many subnets do you want to create? "))
    except ValueError:
        print(f"{CLR_RED}[!] Invalid number of subnets.{CLR_RESET}")
        return

    subnets, error = get_subnet_division(parent, num)

    if error:
        print(f"{CLR_RED}[!] ERROR: {error}{CLR_RESET}")
        return

    report = [f"# SubintMaster Subnet Division Report\n**Parent:** {parent}\n**Requested:** {num} subnets\n"]
    
    print(f"\n{CLR_CYAN}================================================")
    print(f"      ✂️  SUBNET DIVISION REPORT")
    print(f"================================================{CLR_RESET}")

    for i, s in enumerate(subnets, 1):
        line = f"{CLR_BOLD}Subnet #{i:02d}:{CLR_RESET} {s['network']} | Range: {s['range']}"
        print(line)
        report.append(f"- **Subnet #{i:02d}:** {s['network']} ({s['range']})")

    print(f"{CLR_CYAN}================================================{CLR_RESET}")
    print(f"{CLR_GREEN}Successfully created {len(subnets)} subnets.{CLR_RESET}")

    save_choice = input(f"\n{CLR_YELLOW}Save report? (y/N): {CLR_RESET}").lower()
    if save_choice == 'y':
        safe_name = parent.replace('/', '_').replace('.', '_')
        save_report("\n".join(report), safe_name)

def run_vlsm():
    print(f"\n{CLR_YELLOW}[Mode: VLSM Allocation]{CLR_RESET}")
    parent = input("Enter Parent Network (e.g., 192.168.1.0/24): ").strip()
    req_str = input("Enter required hosts separated by commas (e.g.: 50, 20, 10): ").strip()
    
    try:
        requirements = [int(x.strip()) for x in req_str.split(",")]
    except ValueError:
        print(f"{CLR_RED}[!] Error parsing host requirements.{CLR_RESET}")
        return

    results, error = get_vlsm_allocation(parent, requirements)
    
    if error:
        print(f"{CLR_RED}[!] ERROR: {error}{CLR_RESET}")
        return

    report = [f"# IPv4 SubnetMaster VLSM Allocation Report\n**Parent Network:** {parent}\n**Total Requirements:** {len(requirements)}\n"]
    
    print(f"\n{CLR_CYAN}================================================")
    print(f"      🧬 VLSM ALLOCATION REPORT")
    print(f"================================================{CLR_RESET}")

    for i, res in enumerate(results, 1):
        line = (f"{CLR_BOLD}Subnet #{i:02d} (Req: {res['req']} hosts):{CLR_RESET}\n"
                f"   Network: {res['network']}\n"
                f"   Mask:    {res['mask']}\n"
                f"   Range:   {res['range']}\n"
                f"   Prefix:  {res['prefix']}")
        print(line)
        report.append(f"### Subnet #{i:02d} (Req: {res['req']} hosts)\n- **Network:** {res['network']}\n- **Mask:** {res['mask']}\n- **Range:** {res['range']}\n- **Prefix:** {res['prefix']}")
        print(f"{CLR_CYAN}------------------------------------------------{CLR_RESET}")

    print(f"{CLR_CYAN}================================================{CLR_RESET}")
    print(f"{CLR_GREEN}VLSM Allocation Complete.{CLR_RESET}")

    save_choice = input(f"\n{CLR_YELLOW}Save report? (y/N): {CLR_RESET}").lower()
    if save_choice == 'y':
        safe_name = parent.replace('/', '_').replace('.', '_')
        save_report("\n".join(report), safe_name)

def main():
    while True:
        # Clear screen for a clean professional look
        os.system('cls' if os.name == 'nt' else 'clear')
        print_banner()
        print(f"{CLR_BOLD}[ Main Menu ]{CLR_RESET}")
        print(f"1. {CLR_CYAN}Analyze Single Network (IP/Mask){CLR_RESET}")
        print(f"2. {CLR_CYAN}Carve Subnets from Block (Equal Subnets){CLR_RESET}")
        print(f"3. {CLR_CYAN}VLSM Allocation (Variable Sizes){CLR_RESET}")
        print(f"4. {CLR_RED}Exit{CLR_RESET}")
        print(f"{CLR_CYAN}------------------------------------------------{CLR_RESET}")
        
        choice = input(f"{CLR_BOLD}Please select an option (1, 2, or 3): {CLR_RESET}").strip()

        if choice == '1':
            run_analysis()
        elif choice == '2':
            run_division()
        elif choice == '3':
            run_vlsm()
        elif choice == '4' or choice.lower() == 'exit':
            print(f"\n{CLR_GREEN}Exiting IPv4 SubnetMaster... Goodbye!{CLR_RESET}")
            break
        else:
            print(f"{CLR_RED}[!] Invalid selection.{CLR_RESET}")
        
        input(f"\n{CLR_YELLOW}Press Enter to return to menu...{CLR_RESET}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{CLR_RED}[!] Process interrupted by user.{CLR_RESET}")
    except Exception as e:
        print(f"\n{CLR_RED}[!] An unexpected error occurred: {e}{CLR_RESET}")
