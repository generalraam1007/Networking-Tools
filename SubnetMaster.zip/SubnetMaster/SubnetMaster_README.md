# 🌐 IPv4 SubnetMaster

[![Python Version](https://img.shields.io/badge/python-3.x-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Status: Stable](https://img.shields.io/badge/status-stable-success.svg)]()

> **High-performance, professional-grade toolkit for Network Engineers. Eliminate manual errors and master IPv4 subnetting with precision.**

---

## ⚡ At a Glance

| Feature | Capability |
| :--- | :--- |
| 🔍 **Single Analysis** | Instantly calculate Network, Broadcast, and Wildcard masks. |
| ✂️ **Subnet Division** | Effortlessly carve parent blocks into equal-sized subnets. |
| 🧬 **VLSM Engine** | Automated Variable Length Subnet Masking for complex topologies. |
| 📄 **Auto-Reporting** | Every analysis can be exported as a clean, professional **Markdown (.md) report**. |

---

## 🖥️ Visual Demo

*Experience the clarity of SubintMaster's terminal output:*

```text
================================================
      📊 SUBNETMASTER ANALYSIS REPORT
================================================
Input IP:          192.168.20.20
Subnet Mask:       255.255.240.0
Subnet Prefix:     /20
IP Classification: Private (RFC 1918)
Wildcard Mask:     0.0.15.255
Network Address:   192.168.16.0
Broadcast Address: 192.168.31.255
Total Hosts:       4096
Usable Range:      192.168.16.1 - 192.168.31.254
================================================
```

---

## 🚀 Deployment & Usage

### 🖱️ Method 1: The "Quick Start" (Recommended)
*Zero configuration required. Best for rapid results.*

1.  **Ensure Python is installed** ([Download here](https://www.python.org/)).
2.  Locate the `engine.py` file in your project folder.
3.  **Double-scale** `<kbd>engine.py</kbd>` to launch.
4.  Follow the interactive prompts in the terminal window.

### 💻 Method 2: The Developer Way (CLI)
*Perfect for automation, scripting, or integration into workflows.*

1.  Open your Terminal (PowerShell, CMD, or Bash).
2.  Navigate to the project directory (Note: Your path will be different!):
    `<kbd>cd</kbd> "C:\\Path\\To\\Your\\SubnetMaster"`
3.  Run the engine using Python:
    `<kbd>python</kbd> <kbd>SubnetMaster/engine.py</kbd>`

### 🐚 Method 3: Manual PowerShell Execution
*For power users managing specific workspace environments.*

1.  Open **PowerShell**.
2.  Use the `cd` command to enter your local directory:
    `<kbd>cd</kbd> "C:\\Users\\gener\\.lmstudio\\apps\\b%...\\workspace"`
3.  Execute the script directly:
    `<kbd>python</kbd> <kbd>SubnetMaster/engine.py</kbd>`

> [!TIP]
> **Pro Tip:** Always ensure you are in the correct working directory before running via terminal so the tool can correctly locate its internal modules and the `<kbd>reports/</kbd>` folder.

---

## 📂 Project Architecture

```text
SubnetMaster/
├── 🚀 engine.py      # Main entry point & UI Layer
├── 🧠 logic.py       # The computational "brain" (Math Engine)
├── 📁 reports/       # (Auto-generated) Your saved analysis logs
└── 📖 README.md      # This documentation
```

---
*Developed with passion for the Networking Community.* 🌐
