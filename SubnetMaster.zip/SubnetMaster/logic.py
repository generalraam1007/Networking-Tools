import ipaddress
import math

def get_network_info(ip_str, mask_str):
    """
sCalculates key network details for a professional report.
    Returns a dictionary of results.
    """
    try:
        if '/' in ip_str:
            interface = ipaddress.IPv4Interface(ip_str)
        else:
            interface = ipaddress.IPv4Interface(f"{ip_str}/{mask_str}")
        network = interface.network
        
        ip_type = "Private (RFC 1918)" if interface.ip.is_private else "Public"
        wildcard_mask = ipaddress.IPv4Address(int(interface.netmask) ^ 0xFFFFFFFF)
        
        total_hosts = network.num_addresses
        host_bits = 32 - network.prefixlen
        
        results = {
            "input_ip": ip_str,
            "subnet_mask": str(interface.netmask),
            "subnet_prefix": f"/{network.prefixlen}",
            "ip_classification": ip_type,
            "wildcard_mask": str(wildcard_mask),
            "network_address": str(network.network_address),
            "broadcast_address": str(network.broadcast_address),
            "total_hosts": total_hosts,
            "host_bits": host_bits,
            "usable_range": None,
            "usable_hosts": 0
        }

        if network.prefixlen <= 30:
            first_usable = network.network_address + 1
            last_usable = network.broadcast_address - 1
            results["usable_range"] = f"{first_usable} - {last_usable}"
            results["usable_hosts"] = total_hosts - 2
        else:
            results["usable_range"] = "N/A (Point-to-point or Host only)"
            results["usable_hosts"] = 0
            
        return results, None
    except Exception as e:
        return None, str(e)

def get_subnet_division(parent_network_str, num_subnets):
    """
    Takes a parent network and divides it into equal subnets.
    Returns a list of subnet info dictionaries.
    """
    try:
        parent_net = ipaddress.IPv4Network(parent_network_str)
        if num_subnets <= 1:
            return [], "No division needed."

        bits_to_borrow = math.ceil(math.log2(num_subnets))
        new_prefix = parent_net.prefixlen + bits_to_borrow
        
        if new_prefix > 32:
            return [], "Too many subnets requested for this block."

        subnets_data = []
        # Using .subnets(new_prefix=...) is the correct way to get equal-sized chunks
        for i, subnet in enumerate(parent_net.subnets(new_prefix=new_prefix), 1):
            subnets_data.append({
                "id": f"{i:02d}",
                "network": str(subnet.network_address),
                "range": f"{subnet.network_address} - {subnet.broadcast_address}"
            })
        return subnets_data, None
    except Exception as e:
        return [], str(e)

def get_vlsm_allocation(parent_network_str, host_requirements):
    """
    Performs Variable Length Subnet Masking (VLSM) allocation.
    Returns a list of allocated subnet info dictionaries.
    """
    try:
        current_net = ipaddress.IPv4Network(parent_network_str)
        sorted_reqs = sorted(host_requirements, reverse=True)
        
        results = []
        current_address = current_net.network_address

        for i, req in enumerate(sorted_reqs):
            needed_addresses = req + 2
            if needed_addresses < 2:
                 needed_addresses = 2
            host_bits = math.ceil(math.log2(needed_addresses))
            new_prefix = 32 - host_bits
            
            try:
                new_subnet = ipaddress.IPv4Network((current_address, new_prefix))
                
                if (new_subnet.network_address < current_net.network_address or 
                    new_subnet.broadcast_address > current_net.broadcast_address):
                    if i == 0:
                        return [], f"First requirement ({req} hosts) is too large for the parent network."
                    break

                results.append({
                    "req": req,
                    "network": str(new_subnet.network_address),
                    "mask": str(new_subnet.netmask),
                    "range": f"{new_subnet.network_address} - {new_subnet.broadcast_address}",
                    "prefix": f"/{new_subnet.prefixlen}"
                })
                current_address = int(new_subnet.broadcast_address) + 1
            except Exception as e:
                return [], f"Error allocating {req} hosts: {str(e)}"

        return results, None
    except Exception as e:
        return [], str(e)
